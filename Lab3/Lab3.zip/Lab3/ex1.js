var myName = 'Francisc'
var mySurname = 'Bernard'
var myAge = 21
var studyYear = 3
var myHobby = 'somnul'

myAge += 4

console.log("Buna! Ma numesc " + mySurname + " " + myName + "si am " + myAge + " ani. Sunt la Universitatea Politehnica Bucuresti in anul " + studyYear + ". Unul dintre hobby-urile mele este " + myHobby + ".")
console.log(typeof myName)
console.log(typeof myAge)
console.log(typeof myHobby)