var tranzactie1 = true
var tranzactie2 = false

if(tranzactie1)
    console.log("Tranzactie acceptata")

if(tranzactie2) 
    console.log("Tranzactie acceptata")
else
    console.log("Tranzactie refuzata")

//se va afisa tranzactie refuzata pentru ca tranzactie2 = false, deci va intra pe else


