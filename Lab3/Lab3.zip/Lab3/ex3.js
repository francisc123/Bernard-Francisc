var a = 15
var b = 4
var c = 12

console.log(a + " " + c + " " + b)